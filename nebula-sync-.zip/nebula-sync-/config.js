import firebase from 'firebase';
require('@firebase/firestore')

,

    databaseURL: "https://.firebaseio.com",
  };


// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
