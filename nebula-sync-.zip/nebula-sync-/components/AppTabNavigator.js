import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createAppContainer,createSwitchNavigator } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import WelcomeScreen from '../screens/WelcomeScreen';

import ChatScreen from "../screens/ChatScreen" ;
import ProfileScreen from "../screens/ProfileScreen" ;

export const AppTabNavigator = createBottomTabNavigator({
  Chat:{
    screen:ChatScreen
  },
  Profile:{
    screen:ProfileScreen
  },
}) 

